package Tarea1;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
public class UtilsTest {

    @Test
    void testEquilatero() {
        assertEquals("EQUILATERO", Utils.tipoTriangulo(3, 3, 3));
    }

    @Test
    void testIsosceles() {
        assertEquals("ISOSCELES", Utils.tipoTriangulo(3, 4, 3));
    }

    @Test
    void testEscaleno() {
        assertEquals("ESCALENO", Utils.tipoTriangulo(3, 4, 5));
    }

    @Test
    void testNoTriangulo() {
        assertEquals("ERROR", Utils.tipoTriangulo(1, 1, 3));
    }
}
